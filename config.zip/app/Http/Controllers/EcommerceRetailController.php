<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EcommerceRetailController extends Controller
{
    public function EcommerceRetail()
    {
        return view('frontend.pages.EcommerceRetail');
    }
}
