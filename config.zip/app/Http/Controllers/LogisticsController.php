<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LogisticsController extends Controller
{
    public function Logistics()
    {
        return view('frontend.pages.Logistics');
    }
}
